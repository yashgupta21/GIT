#include <iostream>
#include <sys/types.h>
#include <list>
//#include "libbaluff.h"

using namespace std;

int main()
{
    // Balluff obj;
    list<u_int32_t*> lst1, lst2;
    int i;
    for (i = 0; i < 12; i++)
    {
        lst1.push_back((u_int32_t*)malloc(sizeof(u_int32_t)));
        lst2.push_back((u_int32_t*)malloc(sizeof(u_int32_t)));
    }

    list<uint32_t*>::iterator it = lst1.begin();
    for (; it != lst1.end(); it++)
    {
        cout << *it << endl;
    }
    
    // lst1 = (u_int32_t*)malloc(12*sizeof(u_int32_t);
    // lst2 = (u_int32_t*)malloc(12*sizeof(u_int32_t);
    // obj.endpoint_driver_init(lst1, lst2,sizeof(lst1));
    // free(lst1);
    // free(lst2);
}
