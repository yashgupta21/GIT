#include <iostream>
#include <sys/ioctl.h>
#include <list>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include "libballuff.h"
using namespace std;

uint8_t Balluff::endpoint_driver_init(list<uint8_t*> data_cube_addr,list<uint8_t*> meta_data_cube_addr)
{
	
	uint8_t index_n = ZERO;

	cout<<"Opening Charater Driver File"<<endl;
        fd=open(DEVICE_FILE_NAME,O_RDWR);
        if(fd<ZERO)
        {
                cout<<"ERROR: Can not open device file "<<DEVICE_FILE_NAME<<endl;
                return E_ERROR;
        }

	list<uint8_t*>::iterator data_cube_itr = data_cube_addr.begin();
	list<uint8_t*>::iterator meta_data_cube_itr = meta_data_cube_addr.begin();
	
	if (data_cube_addr.size() != meta_data_cube_addr.size())
	{
		cout << "ERROR: List size of data cube and meta data cube is not same." << endl;
		return E_ERR_SIZE_MISMATCH;
	}

	for (; data_cube_itr != data_cube_addr.end() && 
			meta_data_cube_itr != meta_data_cube_addr.end();
			data_cube_itr++, meta_data_cube_itr++)
	{

		data_addresses data;
		data.data_cube_address = *data_cube_itr;
		data.meta_data_cube_address = *meta_data_cube_itr;
		data.index = index_n++;

		if (data.data_cube_address == NULL || data.meta_data_cube_address == NULL)
		{
			cout << "ERROR:NULL address detected..." << endl;
			continue;
		}
		if(ZERO != ioctl(fd, IOCTL_SET_DMA_ADDRESS, &data))
		{
			cout << "ERROR: IOCTL_SET_DMA_ADDRESS" << endl;
			return E_ERROR;
		}    

	}
	return E_SUCCESS;

}

uint8_t Balluff::endpoint_driver_deinit()
{
	if(ZERO!=ioctl(fd, IOCTL_FREE_DMA_ADDRESS, NULL))
	{
		cout<< "ERROR: IOCTL_FREE_DMA_ADDRESS" <<endl;
		return E_ERROR;
	}
	if(fd > ZERO)
	{
		close(fd);
		return E_SUCCESS;
	}
	return E_ERROR;
}
