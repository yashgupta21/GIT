#!/bin/bash

var=$(lsmod | grep -c "fpga_driver")
if [ $var -eq 1 ]
then
	count=1
else
	count=0
fi
if [ $count -eq 0 ]
then
	sudo insmod fpga_driver.ko
	sudo dmesg -C
	sudo ./testapp
	dmesg
else
	sudo rmmod fpga_driver
fi
