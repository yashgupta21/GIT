#include <iostream>
#include <sys/types.h>
#include <list>
#include <fcntl.h>
#include <unistd.h>
#include "libballuff.h"
using namespace std;

int main()
{
	Balluff obj;
	list<u_int8_t*> data_cube_addr,meta_data_cube_addr;
	u_int8_t i, *data_cube,*meta_cube;

	for (i = ZERO; i < LENGTH; i++)
	{
		if(ZERO != posix_memalign((void **)&data_cube, HUGE_PAGE_SIZE, DATACUBE_BUFSIZE))
		{
			cout << "ERROR: Data cube memory allocation failed index"<<i<<endl;
			return E_ERROR;
		}
		data_cube_addr.push_back(data_cube);

		if(ZERO != posix_memalign((void **)&meta_cube, 2048, METACUBE_BUFSIZE))
		{
			cout << "ERROR: Meta data cube memory allocation failed index"<<i<<endl;
			return E_ERROR;
		}
		meta_data_cube_addr.push_back(meta_cube);
	}
	
	/*INIT FUNCTION*/
	if(E_SUCCESS!=obj.endpoint_driver_init(data_cube_addr,meta_data_cube_addr))
	{
		cout<< "ERROR: endpoint_driver_init" << endl;
		return E_ERROR;
	}
	sleep(DELAY);

	// TODO test code to add
	
	/*DEINIT FUNCTION*/
	
	if(E_SUCCESS!=obj.endpoint_driver_deinit())
	{
		cout<< "ERROR: endpoint_driver_deinit" << endl;
		return E_ERROR;
	}
	list<uint8_t*>::iterator it1 = data_cube_addr.begin();
	list<uint8_t*>::iterator it2 = meta_data_cube_addr.begin();
	
	for(i = ZERO ;i<LENGTH;i++)
	{
		free(*it1);
		free(*it2);
		it1++,it2++;
	}
	cout<<"Memory Released "<<endl<<"Closing Driver File"<<endl;
}
