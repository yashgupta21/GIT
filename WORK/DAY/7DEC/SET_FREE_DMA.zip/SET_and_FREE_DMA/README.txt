
List of files associated with you:

	1. balluff_main.cpp(Test Application)
	2. fpga_driver.c (Driver )
	3. libballuff.h (Header file )
	4. libballuff.cpp (Library )
	5. Makefile
	6. test_run.sh (To Executing)

step 1: (Compilation)
	
	Makefile sets in that way you compile code "one by one" or do it at "one instant"

 	one by one-->
		1.Write "make driver"  (All driver related files will be created)
		2.Write "make library" (library object file and library .a file will be created )
		3.Write "make testapp" (test application .o and library will link here and an executable created)
	
	one instant-->
		1.Write "make all" 	(All the compilation stages will be merge in this step)

step 2: (RUN Application)
	
	To Run this entire apllication BASH script is written 
	
	Just  do "sh test_run.sh or bash test_run.sh" on terminal  your application will execute
	
	NOTE: ***Bash script will load and unload Kernal module and dmesg the kernal buffer logs***

step 3: (clean)
	
	Makefile sets in that way you clean code "one by one" or do it at "one instant"

        one by one-->
                1.Write "make clean_driver"  (All driver related files get removed)
                2.Write "make clean_library" (library object file and library .a file get removed )
                3.Write "make clean_testapp" (test application .o and exeutable get removed)

        one instant-->
                1.Write "make all_clean"      (All the compilation stages will be merge in this step)	




