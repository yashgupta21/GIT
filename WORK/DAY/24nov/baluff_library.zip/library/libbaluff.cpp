#include <iostream>
#include <sys/ioctl.h>
#include <list>
#include "libballuff.h"

uint8_t Balluff::send_command(uint8_t channel_index, uint8_t[16] command_data)
{
	
}

uint8_t Balluff::send_command_and_get_response(uint8_t channel_index, uint8_t[16] command_data,
        uint8_t *response_data, uint16_t timeout)
{
	
}

// TODO: remove list_size parameter?
uint8_t Balluff::endpoint_driver_init(list<uint32_t> data_cube_addr,
        list<uint32_t> meta_data_cube_addr, uint8_t list_size)
{
    uint16_t list_size = data_cube_addr.size();
    uint8_t index_n = 0;
    list<uint32_t>::iterator data_cube_itr = data_cube_addr.begin();
    list<uint32_t>::iterator meta_data_cube_itr = meta_data_cube_addr.begin();
    
    // TODO: open_character_device
    // TODO: Validate hugepage memory allocation

    if (data_cube_addr.size() != meta_data_cube_addr.size())
    {
        cout << "List size of data cube and meta data cube is not same." << endl;
        return -1;
    }

    for (; data_cube_itr != data_cube_addr.end() && 
            meta_data_cube_itr != meta_data_cube_addr.end();
            data_cube_itr++, meta_data_cube_itr++)
    {
        uint32_t error;
        data_addresses data;
        data.data_cube_address = *data_cube_itr;
        data.meta_data_cube_address = *meta_data_cube_itr;
        data.index = index_n++;
        
        if (data.data_cube_address == NULL || data.meta_data_cube_address == NULL)
        {
            continue;
            // cout << "Couldn't allocate memory" << endl;
            // TODO: close character driver
            // return error;
        }

        error = ioctl(fd, IOCTL_SET_DMA_ADDRESS, &data);
        
        if (error < 0)
        {
            // TODO: close character driver
            return error;
        }    
    }
    
    return 1;
}

uint8_t Balluff::endpoint_driver_deinit()
{
    uint32_t error;
    error = ioctl(fd, IOCTL_FREE_DMA_ADDRESS, NULL);
    if (error < 0)
    {
        return error;
    }
    
    /* error = close_character_driver();
    if (error)
    {
        return error;
    } */

    return 1;
}

uint8_t Balluff::get_current_data_cube_index(uint8_t index)
{
	
}

uint8_t Balluff::set_card_power(bool state)
{
	
}

uint8_t Balluff::set_trigger_period(uint16_t trigger_period)
{
	
}

uint8_t Balluff::set_measurement_data_length(uint16_t measuremet_length)
{
	
}

uint8_t Balluff::set_low_power_mode(void)
{
	
}

uint8_t Balluff::set_trigger(bool state)
{
	
}

uint8_t Balluff::set_card_numbers(uint16_t card_index_bit)
{
	
}

uint8_t Balluff::get_radar_board_ready_status(uint16_t *card_index_bit)
{
	
}

uint8_t Balluff::soft_reset_fpga(void)
{
	
}

uint8_t Balluff::register_callback_function(void (*func)(void), uint16_t id)
{
	
}

uint32_t Balluff::get_fpga_register_offset(uint32_t cmd, uint8_t index)
{
    switch (cmd)
    {
        case SEND_COMMAND:
            break;

        case COMMAND_RESPONSE:
            break;

        case CURRENT_DATA_CUBE_INDEX:
            break;

        case CARD_POWER:
            break;

        case TRIGGER_PERIOD:
            break;

        case MEASUREMENT_DATA_LENGTH:
            break;

        case TRIGGER_ENABLE:
            break;

        case SELECT_CARD_NUMBERS:
            break;

        case RADAR_READY_STATUS:
            break;

        case FPGA_RESET:
            break;

        default:
            break;
    }
}
