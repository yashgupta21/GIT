#ifndef LIBBALLUFF_H
#define LIBBALLUFF_H

enum
{
    SEND_COMMAND,
    COMMAND_RESPONSE,
    CURRENT_DATA_CUBE_INDEX,
    CARD_POWER,
    TRIGGER_PERIOD,
    MEASUREMENT_DATA_LENGTH,
    TRIGGER_ENABLE,
    SELECT_CARD_NUMBERS,
    RADAR_READY_STATUS,
    FPGA_RESET
} commands;

class Balluff
{
    public:
        Balluff()
        {

        }

        typedef struct _addr
        {
            uint32_t    *data_cube_address;             /* Data cube address */
            uint32_t    *meta_data_cube_address;        /* Meta data cube address */
            uint8_t    index;                           /* Index of the data cube in list */
            // TODO: add data_cube and meta_data_cube offset
        } data_addresses;

        uint8_t fd;
        uint8_t send_command(uint8_t channel_index, uint8_t[16] command_data);
        uint8_t send_command_and_get_response(uint8_t channel_index, uint8_t[16] command_data, 
                uint8_t *response_data, uint16_t timeout);
        uint8_t endpoint_driver_init(list<uint32_t> data_cube_addr, list<uint32_t> meta_data_cube_addr, 
                uint8_t list_size);
        uint8_t endpoint_driver_deinit();
        uint8_t get_current_data_cube_index(uint8_t index);
        uint8_t set_card_power(bool state);
        uint8_t set_trigger_period(uint16_t trigger_period);
        uint8_t set_measurement_data_length(uint16_t measuremet_length);
        uint8_t set_low_power_mode(void);
        uint8_t set_trigger(bool state);
        uint8_t set_card_numbers(uint16_t card_index_bit);
        uint8_t get_radar_board_ready_status(uint16_t *card_index_bit);
        uint8_t soft_reset_fpga(void);
        uint8_t register_callback_function(void (*func)(void), uint16_t id);
        uint32_t get_fpga_register_offset(uint32_t cmd, uint8_t index);
};

#endif
