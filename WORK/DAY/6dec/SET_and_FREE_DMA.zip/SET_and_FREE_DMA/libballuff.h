#ifndef LIBBALLUFF_H
#define LIBBALLUFF_H
#include <iostream>
#include <list>
using namespace std;
#define DEVICE_FILE_NAME "/dev/adaptor_board"
#define METACUBE_BUFSIZE (1024 * 640 )
#define HUGE_PAGE_SIZE 2*1024*1024
#define DATACUBE_BUFSIZE HUGE_PAGE_SIZE*10
#define IOCTL_SET_DMA_ADDRESS _IOW('a','a',data_addresses*)
#define IOCTL_FREE_DMA_ADDRESS _IO('a','b')
enum error_codes
{
    	E_SUCCESS,
	E_ERR_SIZE_MISMATCH,
    	E_ERROR
};
class Balluff
{
    public:
        Balluff()
        {

        }

        typedef struct _data_addr
        {
            // TODO: does the following two variables needs to be a pointer?
            uint8_t   *data_cube_address;             /* Data cube address */
            uint8_t   *meta_data_cube_address;        /* Meta data cube address */
            uint8_t    index;                          /* Index of the data cube in list */
            // TODO: add data_cube and meta_data_cube offset
        } data_addresses;
	uint8_t     fd;
        uint8_t     endpoint_driver_init(list<uint8_t*> data_cube_addr, list<uint8_t*> meta_data_cube_addr);
	uint8_t     endpoint_driver_deinit();
};
#endif 

